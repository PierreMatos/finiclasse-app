<!-- Benefits Id Field -->
<div class="col-sm-12">
    {!! Form::label('benefits_id', 'Benefits Id:') !!}
    <p>{{ $benefitsBusinessStudy->benefits_id }}</p>
</div>

<!-- Business Study Id Field -->
<div class="col-sm-12">
    {!! Form::label('business_study_id', 'Business Study Id:') !!}
    <p>{{ $benefitsBusinessStudy->business_study_id }}</p>
</div>

<!-- Created At Field -->
<div class="col-sm-12">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{{ $benefitsBusinessStudy->created_at }}</p>
</div>

<!-- Updated At Field -->
<div class="col-sm-12">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{{ $benefitsBusinessStudy->updated_at }}</p>
</div>

<!-- Deleted At Field -->
<div class="col-sm-12">
    {!! Form::label('deleted_at', 'Deleted At:') !!}
    <p>{{ $benefitsBusinessStudy->deleted_at }}</p>
</div>

