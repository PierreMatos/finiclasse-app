




<li class="nav-item">
    <a href="{{ route('stands.index') }}"
       class="nav-link {{ Request::is('stands*') ? 'active' : '' }}">
        <p>Stands</p>
    </a>
</li>



<li class="nav-item">
    <a href="{{ route('makes.index') }}"
       class="nav-link {{ Request::is('makes*') ? 'active' : '' }}">
        <p>Makes</p>
    </a>
</li>




<li class="nav-item">
    <a href="{{ route('carCategories.index') }}"
       class="nav-link {{ Request::is('carCategories*') ? 'active' : '' }}">
        <p>Car Categories</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('carClasses.index') }}"
       class="nav-link {{ Request::is('carClasses*') ? 'active' : '' }}">
        <p>Car Classes</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('carClasses.index') }}"
       class="nav-link {{ Request::is('carClasses*') ? 'active' : '' }}">
        <p>Car Classes</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('carConditions.index') }}"
       class="nav-link {{ Request::is('carConditions*') ? 'active' : '' }}">
        <p>Car Conditions</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('carDrives.index') }}"
       class="nav-link {{ Request::is('carDrives*') ? 'active' : '' }}">
        <p>Car Drives</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('carStates.index') }}"
       class="nav-link {{ Request::is('carStates*') ? 'active' : '' }}">
        <p>Car States</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('carTransmissions.index') }}"
       class="nav-link {{ Request::is('carTransmissions*') ? 'active' : '' }}">
        <p>Car Transmissions</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('carModels.index') }}"
       class="nav-link {{ Request::is('carModels*') ? 'active' : '' }}">
        <p>Car Models</p>
    </a>
</li>









<li class="nav-item">
    <a href="{{ route('proposalStates.index') }}"
       class="nav-link {{ Request::is('proposalStates*') ? 'active' : '' }}">
        <p>Proposal States</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('benefits.index') }}"
       class="nav-link {{ Request::is('benefits*') ? 'active' : '' }}">
        <p>Benefits</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('businenssStudyAuthorizations.index') }}"
       class="nav-link {{ Request::is('businenssStudyAuthorizations*') ? 'active' : '' }}">
        <p>Businenss Study Authorizations</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('businessStudies.index') }}"
       class="nav-link {{ Request::is('businessStudies*') ? 'active' : '' }}">
        <p>Business Studies</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('benefitsBusinessStudies.index') }}"
       class="nav-link {{ Request::is('benefitsBusinessStudies*') ? 'active' : '' }}">
        <p>Benefits Business Studies</p>
    </a>
</li>




<li class="nav-item">
    <a href="{{ route('proposals.index') }}"
       class="nav-link {{ Request::is('proposals*') ? 'active' : '' }}">
        <p>Proposals</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('financings.index') }}"
       class="nav-link {{ Request::is('financings*') ? 'active' : '' }}">
        <p>Financings</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('financingProposals.index') }}"
       class="nav-link {{ Request::is('financingProposals*') ? 'active' : '' }}">
        <p>Financing Proposals</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('carFuels.index') }}"
       class="nav-link {{ Request::is('carFuels*') ? 'active' : '' }}">
        <p>Car Fuels</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('cars.index') }}"
       class="nav-link {{ Request::is('cars*') ? 'active' : '' }}">
        <p>Cars</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('users.index') }}"
       class="nav-link {{ Request::is('users*') ? 'active' : '' }}">
        <p>Users</p>
    </a>
</li>


