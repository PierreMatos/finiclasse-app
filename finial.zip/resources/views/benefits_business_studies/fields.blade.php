<!-- Benefits Id Field -->
<div class="form-group col-sm-6">
    {!! Form::label('benefits_id', 'Benefits Id:') !!}
    {!! Form::number('benefits_id', null, ['class' => 'form-control']) !!}
</div>

<!-- Business Study Id Field -->
<div class="form-group col-sm-6">
    {!! Form::label('business_study_id', 'Business Study Id:') !!}
    {!! Form::number('business_study_id', null, ['class' => 'form-control']) !!}
</div>