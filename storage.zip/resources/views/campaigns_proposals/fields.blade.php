<!-- Campaign Id Field -->
<div class="form-group col-sm-6">
    {!! Form::label('campaign_id', 'Campaign Id:') !!}
    {!! Form::number('campaign_id', null, ['class' => 'form-control']) !!}
</div>

<!-- Proposal Id Field -->
<div class="form-group col-sm-6">
    {!! Form::label('proposal_id', 'Proposal Id:') !!}
    {!! Form::number('proposal_id', null, ['class' => 'form-control']) !!}
</div>