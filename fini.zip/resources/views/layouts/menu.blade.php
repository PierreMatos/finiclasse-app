<li class="nav-item">
    <a href="{{ route('users.index') }}"
       class="nav-link {{ Request::is('users*') ? 'active' : '' }}">
        <p>Users</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('users.index') }}"
       class="nav-link {{ Request::is('users*') ? 'active' : '' }}">
        <p>Users</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('users.index') }}"
       class="nav-link {{ Request::is('users*') ? 'active' : '' }}">
        <p>Users</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('users.index') }}"
       class="nav-link {{ Request::is('users*') ? 'active' : '' }}">
        <p>Users</p>
    </a>
</li>



<li class="nav-item">
    <a href="{{ route('stands.index') }}"
       class="nav-link {{ Request::is('stands*') ? 'active' : '' }}">
        <p>Stands</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('proposalStates.index') }}"
       class="nav-link {{ Request::is('proposalStates*') ? 'active' : '' }}">
        <p>Proposal States</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('makes.index') }}"
       class="nav-link {{ Request::is('makes*') ? 'active' : '' }}">
        <p>Makes</p>
    </a>
</li>




<li class="nav-item">
    <a href="{{ route('carCategories.index') }}"
       class="nav-link {{ Request::is('carCategories*') ? 'active' : '' }}">
        <p>Car Categories</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('carClasses.index') }}"
       class="nav-link {{ Request::is('carClasses*') ? 'active' : '' }}">
        <p>Car Classes</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('carClasses.index') }}"
       class="nav-link {{ Request::is('carClasses*') ? 'active' : '' }}">
        <p>Car Classes</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('carConditions.index') }}"
       class="nav-link {{ Request::is('carConditions*') ? 'active' : '' }}">
        <p>Car Conditions</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('carDrives.index') }}"
       class="nav-link {{ Request::is('carDrives*') ? 'active' : '' }}">
        <p>Car Drives</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('carStates.index') }}"
       class="nav-link {{ Request::is('carStates*') ? 'active' : '' }}">
        <p>Car States</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('carTransmissions.index') }}"
       class="nav-link {{ Request::is('carTransmissions*') ? 'active' : '' }}">
        <p>Car Transmissions</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('carModels.index') }}"
       class="nav-link {{ Request::is('carModels*') ? 'active' : '' }}">
        <p>Car Models</p>
    </a>
</li>


