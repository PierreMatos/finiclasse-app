<li class="nav-item">
    <a href="<?php echo e(route('users.index')); ?>"
       class="nav-link <?php echo e(Request::is('users*') ? 'active' : ''); ?>">
        <p>Users</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('users.index')); ?>"
       class="nav-link <?php echo e(Request::is('users*') ? 'active' : ''); ?>">
        <p>Users</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('users.index')); ?>"
       class="nav-link <?php echo e(Request::is('users*') ? 'active' : ''); ?>">
        <p>Users</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('users.index')); ?>"
       class="nav-link <?php echo e(Request::is('users*') ? 'active' : ''); ?>">
        <p>Users</p>
    </a>
</li>


<?php /**PATH C:\Projects\finiclasse-app\resources\views/layouts/menu.blade.php ENDPATH**/ ?>